﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Media.Imaging;

namespace MiniGame_TeamProjekt
{
    public class Card
    {
        private static int ID = 0;
        private int _cardID;
        private int _numberForImage;
        private BitmapImage _bitmapImage;

        private readonly List<string> _pictureNames = new List<string>
        {
            "01_image-House.jpg",
            "02_image-Flower.jpg",
            "03_image-Notes.jpg",
            "04_image-Icecream.jpg",
            "05_image-Cactus.png",
            "06_image-Ghost.png",
            "09_image-Bird.png",
            "10_image-Dice.png",
            "11_image-Rocket.png",
            "12_image-Heart.png"
        };

        public Card(int numberForImage)
        {
            _cardID = ID++;
            _numberForImage = numberForImage;
            BitmapImage bitmapImage = new BitmapImage();
            _bitmapImage = GetImage();
        }

        public int CardId
        {
            get { return _cardID; }
            set { _cardID = value; }
        }

        public int NumberForImage
        {
            get { return _numberForImage; }
            set { _numberForImage = value; }
        }

        public BitmapImage BitmapImage
        {
            get { return _bitmapImage; }
            set { _bitmapImage = value; }
        }

        public BitmapImage GetImage()
        {
            // number from listNumbers -> mainWindow
            // create image
            BitmapImage imageHouse = new BitmapImage();
            imageHouse.BeginInit();
            Uri uri = new Uri(Path.Combine(@"C:\Local\Work\Kurse\FH_C#\Projekte\Main-main\Menu\Menu", "Pictures", _pictureNames[_numberForImage]));
            imageHouse.UriSource = uri;
            imageHouse.EndInit();
            return imageHouse;
            //C:\Local\Work\Kurse\FH_C#\Projekte\Main-main\Menu\Menu\Pictures\01_image-House.jpg
        }
    }
}