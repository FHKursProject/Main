﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Menu
{
    /// <summary>
    /// Interaktionslogik für Pong.xaml
    /// </summary>
    public partial class Pong : Window
    {
        private bool _p1Up = false;
        private bool _p2Up = false;
        private bool _p1Down = false;
        private bool _p2Down = false;

        private double _positionX = 390;
        private double _positionY = 205;
        private double _speedX = -0.1;
        private double _speedY = 0.1;
        private double _startSpeedX = 0.1;
        private double _startSpeedY = 0.1;
        private double _acceleration = 1;

        Random _random = new Random();

        DispatcherTimer _timerPlayers = new DispatcherTimer();
        DispatcherTimer _timerBall = new DispatcherTimer();
        MainWindow _mainWindow;
        public Pong(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            _timerPlayers.Interval = TimeSpan.FromMilliseconds(5);
            _timerPlayers.Tick += Moveplayer;
            _timerBall.Interval = TimeSpan.FromMilliseconds(50);
            _timerBall.Tick += MoveBall;
        }

        public void Moveplayer(object sender, EventArgs e)
        {
            if (_p1Up)
            {
                if (Canvas.GetTop(P1) >= 0)
                {
                    Canvas.SetTop(P1, Canvas.GetTop(P1) - 10);
                }
            }
            if (_p1Down)
            {
                if (Canvas.GetTop(P1) <= Gamefield.ActualHeight - 100)
                {
                    Canvas.SetTop(P1, Canvas.GetTop(P1) + 10);
                }
            }
            if (_p2Up)
            {
                if (Canvas.GetTop(P2) >= 0)
                {
                    Canvas.SetTop(P2, Canvas.GetTop(P2) - 10);
                }
            }
            if (_p2Down)
            {
                if (Canvas.GetTop(P2) <= Gamefield.ActualHeight - 100)
                {
                    Canvas.SetTop(P2, Canvas.GetTop(P2) + 10);
                }
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.W:
                    _p1Up = true;
                    break;
                case Key.S:
                    _p1Down = true;
                    break;
                case Key.Up:
                    _p2Up = true;
                    break;
                case Key.Down:
                    _p2Down = true;
                    break;
                default:
                    break;
            }
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.W:
                    _p1Up = false;
                    break;
                case Key.S:
                    _p1Down = false;
                    break;
                case Key.Up:
                    _p2Up = false;
                    break;
                case Key.Down:
                    _p2Down = false;
                    break;
                default:
                    break;
            }
        }

        //Ball
        private void MoveBall(object sender, EventArgs e)
        {
            var xleft = Canvas.GetLeft(Ball);
            var ytop = Canvas.GetTop(Ball);

            //Hit PaddleLeft
            if (xleft <= P1.Width && ytop >= Canvas.GetTop(P1) && ytop + Ball.Height <= Canvas.GetTop(P1) + P1.Height)
            {
                _speedX = -_speedX;
            }

            //Hit PaddleRight
            if (xleft + Ball.Width >= Gamefield.ActualWidth - (Canvas.GetRight(P2) + P2.Width) && ytop + P2.Width >= Canvas.GetTop(P2) && ytop + Ball.Height <= Canvas.GetTop(P2) + P2.Height)
            {
                _speedX = -_speedX;
            }

            //Hit Wall
            if (ytop >= Gamefield.ActualHeight - Ball.Height || ytop <= 0.0)
            {
                _speedY = -_speedY;
            }

            //LeftPlayer makes Goal
            if (xleft >= 10 + Gamefield.ActualWidth)
            {
                _speedX = _startSpeedX;
                _speedY = _startSpeedY;
                Canvas.SetLeft(Ball, _positionX);
                Canvas.SetTop(Ball, _positionY);
                PointsP1.Content = Convert.ToInt32(PointsP1.Content) + 1;
                return;
            }

            //RightPlayer makes Goal
            if (xleft <= -10 - Ball.Width)
            {
                _speedX = _startSpeedX;
                _speedY = _startSpeedY;
                Canvas.SetLeft(Ball, _positionX);
                Canvas.SetTop(Ball, _positionY);
                PointsP2.Content = Convert.ToInt32(PointsP2.Content) + 1;
                return;
            }

            //Accelerate Ball
            _speedX *= _acceleration;
            _speedY *= _acceleration;

            //Ball Movement
            xleft += _speedX * _timerBall.Interval.TotalMilliseconds;
            ytop += _speedY * _timerBall.Interval.TotalMilliseconds;
            Canvas.SetLeft(Ball, xleft);
            Canvas.SetTop(Ball, ytop);

            //Win
            if (Convert.ToInt32(PointsP1.Content) == 10)
            {
                MessageBox.Show("Player 1 wins. Player 2 sucks.");
                PointsP1.Content = "0";
                PointsP2.Content = "0";
                Stop();
            }
            if (Convert.ToInt32(PointsP2.Content) == 10)
            {
                MessageBox.Show("Player 2 wins. Player 1 sucks.");
                PointsP1.Content = "0";
                PointsP2.Content = "0";
                Stop();
            }
        }

        private void Easy_Clicked(object sender, RoutedEventArgs e)
        {
            //start pong
            _timerPlayers.Start();
            _timerBall.Start();

            //set Speed without acceleration
            _startSpeedX = 0.2;
            _startSpeedY = 0.2;
            _acceleration = 1.0;

            //hide buttons
            Easy.Visibility = Visibility.Hidden;
            Medium.Visibility = Visibility.Hidden;
            Hard.Visibility = Visibility.Hidden;
        }

        private void Medium_Clicked(object sender, RoutedEventArgs e)
        {
            //start pong
            _timerPlayers.Start();
            _timerBall.Start();

            //set speed with acceleration
            _startSpeedX = 0.15;
            _startSpeedY = 0.15;
            _acceleration = 1.02;

            //hide buttons
            Easy.Visibility = Visibility.Hidden;
            Medium.Visibility = Visibility.Hidden;
            Hard.Visibility = Visibility.Hidden;
        }

        private void Hard_Clicked(object sender, RoutedEventArgs e)
        {
            //start pong
            _timerPlayers.Start();
            _timerBall.Start();

            //set speed with acceleration
            _startSpeedX = 0.20;
            _startSpeedY = 0.20;
            _acceleration = 1.03;

            //hide buttons
            Easy.Visibility = Visibility.Hidden;
            Medium.Visibility = Visibility.Hidden;
            Hard.Visibility = Visibility.Hidden;
        }

        public void Stop()
        {
            _timerPlayers.Stop();
            _timerBall.Stop();
            this.Close();
            _mainWindow.Visibility = Visibility.Visible;
        }
    }
}
