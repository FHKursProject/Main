﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menu
{
    public class PlayerStatistics
    {
        public PlayerStatistics()
        {
            GamesPlayed = 0;
            ColorGameHighScore = 0;
            ReactionGameHighScore = null;
            AimGameHighScore = null;

            //GamesPlayed = player.PlayerStatistics.GamesPlayed;
            //ColorGameHighScore = player.PlayerStatistics.ColorGameHighScore;
            //ReactionGameHighScore = player.PlayerStatistics.ReactionGameHighScore;
            //AimGameHighScore = player.PlayerStatistics.AimGameHighScore;
        }

        public int GamesPlayed { get; set; }

        public int ColorGameHighScore { get; set; }

        public TimeSpan? ReactionGameHighScore { get; set; }

        public TimeSpan? AimGameHighScore { get; set; }

        public void AddPlayedGame()
        {
            GamesPlayed++;
        }

        public void UpdateColorGameHighScore(int highScore)
        {
            if(ColorGameHighScore < highScore)
            {
                ColorGameHighScore = highScore;
            }        
        }

        public void UpdateReactionGameHighScore(TimeSpan highScore)
        {
            if(ReactionGameHighScore > highScore || ReactionGameHighScore == TimeSpan.Zero)
            {
                ReactionGameHighScore = highScore;
            }         
        }

        public void UpdateAimGameHighScore(TimeSpan highScore)
        {
            if(AimGameHighScore > highScore || ReactionGameHighScore == TimeSpan.Zero)
            {
                AimGameHighScore = highScore;
            }
        }     
    }
}
