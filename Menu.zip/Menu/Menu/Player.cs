﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menu
{
    public class Player
    {
        private string _userName;
        private string _password;
        private PlayerStatistics _playerStatistics;

        public Player(string userName, string password)
        {
            _userName = userName;
            _password = password;         
        }

        public string UserName { get { return _userName; } set { _userName = value; } }

        public string Password { get { return _password; } }

        public PlayerStatistics PlayerStatistics { get { return _playerStatistics; } set { _playerStatistics = value; } }

        public bool CheckPassword(string passwordTry)
        {
            if(passwordTry == _password)
            {
                return true;
            }
            return false;
        }

    }
}
