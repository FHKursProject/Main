﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace Menu
{
    /// <summary>
    /// Interaktionslogik für ReactionGame.xaml
    /// </summary>
    public partial class ReactionGame : Window
    {
        private MainWindow _mainWindow;
        private int _counter = 0;
        private Color _color = new Color();
        private Stopwatch _stopwatch = new Stopwatch();
        private Random _random = new Random(Guid.NewGuid().GetHashCode());

        public ReactionGame(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
        }

        public Color SwitchColor()
        {         
            switch (_random.Next(0,7))
            {
                case 0: _color = Color.FromRgb(0, 0, 255); 
                    break; //blue
                case 1: _color = Color.FromRgb(255, 0, 0); 
                    break; //red
                case 2: _color = Color.FromRgb(255, 128, 0); 
                    break; //orange
                case 3: _color = Color.FromRgb(255, 255, 0); 
                    break; // yellow
                case 4: _color = Color.FromRgb(0, 255, 0); 
                    break; //green
                case 5: _color = Color.FromRgb(0, 255, 255); 
                    break; //blue
                case 6: _color = Color.FromRgb(127, 0, 255); 
                    break; //pink
                case 7: _color = Color.FromRgb(96, 96, 96); 
                    break; //gray
                default: break;
            }     
            return _color;
        }

        async void Start_Click(object sender, RoutedEventArgs e)
        {
            Start.Visibility = Visibility.Hidden;
            bool isGreen = false;
            Color color1 = SwitchColor();
            rightRect.Fill = new LinearGradientBrush(color1, color1, 0);

            while (!isGreen)
            {
                if (color1 == Color.FromRgb(0, 255, 0))
                {
                    rightRect.Fill = new LinearGradientBrush(color1, color1, 0);
                    ReactionCount();
                    isGreen = true;
                }
                else
                {
                    await Task.Delay(1000);
                    color1 = SwitchColor();
                    rightRect.Fill = new LinearGradientBrush(color1, color1, 0);
                    _counter++;
                }
            }
        }        

        public void ReactionCount()
        {
            _stopwatch.Start();
        }

        private void ClickHere_Click(object sender, RoutedEventArgs e)
        {
            _stopwatch.Stop();
            _stopwatch.ToString();
            reactionTime.Content = _stopwatch.Elapsed.ToString() + " " + _counter;
        }

        private void ReactionGame_IsNotVisible(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (_mainWindow.LoggedPlayer != null)
            {
                _mainWindow.LoggedPlayer.PlayerStatistics.UpdateReactionGameHighScore(_stopwatch.Elapsed);
                JsonSerializationService.UpdateJsonFile();
            }  
            _mainWindow.Visibility = Visibility.Visible;
        }
    }
}