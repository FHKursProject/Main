﻿using System.Windows;
using MiniGame_TeamProjekt;

namespace Menu
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Player LoggedPlayer;
        public MainWindow()
        {
            InitializeComponent();

            JsonSerializationService.FetchPlayersFromJson();
        }

        private void ColorGame_Click(object sender, RoutedEventArgs e)
        {
            ColorGame colorGame = new ColorGame(this);
            colorGame.Show();
            if (LoggedPlayer != null)
            {
                LoggedPlayer.PlayerStatistics.AddPlayedGame();
            }
            Visibility = Visibility.Hidden;
        }

        private void Memory_Click(object sender, RoutedEventArgs e)
        {
            MemoryGame memoryGame = new MemoryGame(this);
            memoryGame.Show();
            if(LoggedPlayer != null)
            {
                LoggedPlayer.PlayerStatistics.AddPlayedGame();
            }         
            Visibility = Visibility.Hidden;
        }

        private void ReactionGame_Click(object sender, RoutedEventArgs e)
        {
            ReactionGame reactionGame = new ReactionGame(this);
            reactionGame.Show();
            if (LoggedPlayer != null)
            {
                LoggedPlayer.PlayerStatistics.AddPlayedGame();
            }
            Visibility = Visibility.Hidden;
        }

        private void AimExercise_Click(object sender, RoutedEventArgs e)
        {
            AimExercise aimExcercise = new AimExercise(this);
            aimExcercise.Show();
            if (LoggedPlayer != null)
            {
                LoggedPlayer.PlayerStatistics.AddPlayedGame();
            }
            Visibility = Visibility.Hidden;
        }

        private void Pong_Click(object sender, RoutedEventArgs e)
        {
            Pong pong = new Pong(this);
            pong.Show();
            if (LoggedPlayer != null)
            {
                LoggedPlayer.PlayerStatistics.AddPlayedGame();
            }
            Visibility = Visibility.Hidden;
        }

        private void LoginMenuButton_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow(this);
            loginWindow.Show();
            Visibility = Visibility.Hidden;
        }

        private void LogOffMenuButton_Click(object sender, RoutedEventArgs e)
        {
            if(LoggedPlayer != null)
            {
                LoggedPlayer = null;
                tb_Greeting.Text = "Hello!";
                LoginMenuButton.IsEnabled = true;
                LogOffMenuButton.IsEnabled = false;
                btn_Highscores.IsEnabled = false;
                tb_Hint.Text = "If you want to see your statistics \nlog in and press the button!";
            }
        }

        private void btn_Highscores_Click(object sender, RoutedEventArgs e)
        {
            PlayerStatisticView statisticsView = new PlayerStatisticView(this);
            Visibility = Visibility.Hidden;
            statisticsView.Show();
        }

        private void MainMenu_Closed(object sender, System.EventArgs e)
        {
            JsonSerializationService.UpdateJsonFile();
        }
    }
}
