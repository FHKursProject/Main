﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;


namespace Menu
{
    class JsonSerializationService
    {
        private static List<Player> _playersList = new List<Player>();

        public static List<Player> PlayersList { get { return _playersList; } set { _playersList = value; } }

        public static void UpdateJsonFile()
        {
            string jsonString = JsonSerializer.Serialize(_playersList);
            if (!File.Exists(@"../../../JsonFiles/Statistics.json"))
            {
                File.WriteAllText(@"../../../JsonFiles/Statistics.json", jsonString);
            }
            else
            {
                File.Delete(@"../../../JsonFiles/Statistics.json");
                File.WriteAllText(@"../../../JsonFiles/Statistics.json", jsonString);
            }
           
        }

        public static List<Player> FetchPlayersFromJson()
        {
            string jsonString = File.ReadAllText(@"../../../JsonFiles/Statistics.json");
            _playersList = JsonSerializer.Deserialize<List<Player>>(jsonString);

            return _playersList;
        }
    }
}
