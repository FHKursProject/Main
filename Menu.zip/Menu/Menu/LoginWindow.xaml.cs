﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Menu
{
    /// <summary>
    /// Interaktionslogik für LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private MainWindow _mainWindow;
        public LoginWindow(MainWindow mainWindow)
        {
            _mainWindow = mainWindow;
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            foreach(Player player in JsonSerializationService.PlayersList)
            {
                if(player.Password == pb_Password.Password && player.UserName == tb_UserName.Text)
                {
                    _mainWindow.LoggedPlayer = player;
                    this.Visibility = Visibility.Hidden;
                    _mainWindow.LoginMenuButton.IsEnabled = false;
                    _mainWindow.LogOffMenuButton.IsEnabled = true;
                    _mainWindow.tb_Greeting.Text = "Hello " + player.UserName + "!";
                    _mainWindow.tb_Hint.Text = "If you want to see you statistics \ntry and press the button!";
                    _mainWindow.btn_Highscores.IsEnabled = true;
                    _mainWindow.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
