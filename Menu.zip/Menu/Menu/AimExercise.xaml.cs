﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Menu
{
    /// <summary>
    /// Interaktionslogik für AimExercise.xaml
    /// </summary>
    public partial class AimExercise : Window
    {
        private MainWindow _mainWindow;
        private Stopwatch _stopwatch = new Stopwatch();
        private int _counter = 0;
        public AimExercise(MainWindow mainWindow)
        {
            _mainWindow = mainWindow;
            InitializeComponent();
        }

        private async void Start_Click(object sender, RoutedEventArgs e)
        {
            Timers.Visibility = Visibility.Visible;   
            Timers.Text = "3";
            await Task.Delay(1000);
            Timers.Text = "2";
            await Task.Delay(1000);
            Timers.Text = "1";
            await Task.Delay(1000);
            Aim.Visibility = Visibility.Visible;
            _stopwatch.Start();
        }      

        private void Aim_MouseEnter(object sender, MouseEventArgs e)
        {
            Random number = new Random();
            int size = number.Next(50, 100);
            Width = size;
            Height = size;
            int posA = number.Next(-400,400);
            int posB = number.Next(-225, 225);
            Margin = new Thickness(posA, posB, 0, 0);
            _counter++;
            if (_counter == 15)
            {
                this.Close();
                _stopwatch.Stop();
                _stopwatch.ToString();
                TImebox.Text = _stopwatch.Elapsed.ToString();

                if (_mainWindow.LoggedPlayer != null)
                {
                    _mainWindow.LoggedPlayer.PlayerStatistics.UpdateAimGameHighScore(_stopwatch.Elapsed);
                    JsonSerializationService.UpdateJsonFile();
                }
               
                _mainWindow.Visibility = Visibility.Visible;
            }
        }
    }
}
